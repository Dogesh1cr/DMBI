https://chatgpt.com/share/68029173-26e4-800e-8ca9-dbe30d59b85a

https://chatgpt.com/share/68029196-0988-800e-9e53-9733714cc35d

https://chatgpt.com/share/68031728-5658-800e-9d97-4b436bddb10d

https://chatgpt.com/share/6803163a-5464-800a-9290-64f645c4e309

https://chatgpt.com/share/6802c353-7984-8006-8ec8-845398dd6e71

https://jan.ai/

https://github.com/riiddhii28/dmbi

s.id/dmbilab
